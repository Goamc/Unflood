﻿using DG.Tweening;
using UnityEngine;

public class MiceController : MonoBehaviour {
    
    float movex;
    float movey;
    float nextplacex;
    float nextplacey;
    public FloodController flood;
    public Rigidbody2D rb;
    public bool onGround;
    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        onGround = false;
        moving();
		
    }

    private void FixedUpdate()
    {
        nextplacey = flood.transform.position.y + 3.50f;
        if (onGround)
        {
            nextplacey = transform.position.y;
        }else if (nextplacey <= -0.45f)
        {
            nextplacey = -0.45f;
        }else if (nextplacey >= 5.95f)
        {
            nextplacey = 5.95f;
        }
        transform.position = new Vector2(transform.position.x, nextplacey);
    }
    void moving () {
        movex = Random.Range(-2, 3);
        nextplacex = transform.position.x + movex;
        if (nextplacex <= -10.92f) {
            nextplacex = -10.92f;
        }
        if(nextplacex >= 10.92f)
        {
            nextplacex = 10.92f;
        }
        gameObject.transform.DOMoveX(nextplacex, 1f).SetEase(Ease.Linear).OnComplete(moving);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground" || collision.gameObject.tag == "Sewer")
        {
            onGround = true;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground" || collision.gameObject.tag == "Sewer" || collision.gameObject.tag == "FreeSewer")
        {
            onGround = false;
        }
    }
}
