﻿using UnityEngine;

public class SewerController : MonoBehaviour {
    private void OnCollisionEnter2D(Collision2D collision)//tocar nos waste
    {
        gameObject.tag = "Sewer";
    }
    private void OnCollisionStay2D(Collision2D collision)
    {
        gameObject.tag = "Sewer";
    }
    private void OnCollisionExit2D(Collision2D collision)//soltar os waste
    {
        gameObject.tag = "FreeSewer";
    }
}
