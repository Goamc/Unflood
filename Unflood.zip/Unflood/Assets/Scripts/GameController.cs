﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class GameController : MonoBehaviour
{
    
    public static float health;
    public static float breath;
    static GameController instance = null;
    public GameObject player; //amarracao via GUI
    public GameObject flood; //amarracao via GUI


    public static GameController Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new GameObject("GM").AddComponent<GameController>();
                DontDestroyOnLoad(instance);
            }
            return instance;
        }
    }
    private void Awake()
    {
        health = 100;
        breath = 100;
    }

    public void loseHealth(float qtd)
    {
        health = health - qtd;
        if (health <= 0)
        {
            SceneManager.LoadScene("GameOver");
            return;
        }
    }
    public void gainHealth(float qtd)
    {
        health = health + qtd;
    }
    public void loseBreath(float qtd)
    {
        breath = breath - qtd;
        if (breath <= 0)
        {
            SceneManager.LoadScene("GameOver");
            return;
        }
    }
    public void gainBreath(float qtd)
    {
        breath = breath + qtd;
    }

    public void Update()
    {
        if (player.transform.position.y <= flood.transform.position.y + 3.43f)
        {
            Instance.loseBreath(0.5f);
        }
    }
    public void printdados()
    {
        Debug.Log("Health: " + health);
        Debug.Log("Breath: " + breath);
    }
}
