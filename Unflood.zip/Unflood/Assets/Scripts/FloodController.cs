﻿using UnityEngine;
using DG.Tweening;
using UnityEngine.SceneManagement;
public class FloodController : MonoBehaviour
{
    public PlayerController player; //instanciado na GUI
    public float ini = -4.5f;//posicao inicio
    public float limit; //posicao onde a fase ira parar, definido na cena
    public float ground; //posicao onde a agua atinge o nivel do solo mais baixo
    public float vel_pps; //velocidade em pixels por segundo, definido na cena
    
    float speed;
    float spread_effect;
    float contSewer;
    float totalSewer;


    private void Awake()
    {
        DOTween.Init();
    }
    private void Start()
    {
        totalSewer = GameObject.FindGameObjectsWithTag("Sewer").Length+ GameObject.FindGameObjectsWithTag("FreeSewer").Length;
        contSewer = totalSewer;
        spread_effect = 2;
        speed = vel_pps;
        moveWater();
    }
    
    private void FixedUpdate()
    {
        if (player.transform.position.y >=transform.position.y+3.5f)
        {
            player.falling = true;
            player.underwater = 0;
            player.rb.gravityScale = 1;
        }
        else if (player.transform.position.y >= transform.position.y + 3.355f)
        {
            player.underwater = 1;
            player.rb.gravityScale = -0.05f;
            if (player.falling)
            {
                if (player.rb.velocity.y < -1f)
                {
                    player.rb.velocity = new Vector2(player.xspd, -0.5f); //atenua pousos na agua
                }else if (player.rb.velocity.y < 0)
                {
                    player.rb.velocity = new Vector2(player.xspd, 0);
                }
            }
            player.falling = false;
        }
        else
        {
            player.underwater = 2;
            player.rb.gravityScale = -0.05f;
            player.falling = false;
        }
        /*a agua sobe mais rapido quando nao esta espalhada pela superficie
          ao passar o nivel do solo começa a se espalhar, entao a velocidade diminui
        */
        if (gameObject.transform.position.y >= ground)
        {
            spread_effect=1;
        }
        else
        {
            spread_effect = 2;
        }

        
        contSewer = GameObject.FindGameObjectsWithTag("Sewer").Length;
        if (gameObject.transform.position.y < ini)
        {
            SceneManager.LoadScene("Win");
        }
        else if (gameObject.transform.position.y >= limit)
        {
            SceneManager.LoadScene("GameOver");
        }
    }

    private void moveWater() 
    {
        speed = (spread_effect* vel_pps * (contSewer / totalSewer)) -12;
        float pixels = gameObject.transform.position.y+((speed/100));
        gameObject.transform.DOMoveY(pixels, 1).SetEase(Ease.Linear).OnComplete(() => moveWater());
    }
}
