﻿using UnityEngine;

public class CameraController : MonoBehaviour
{

    public GameObject player; //associacao do player feita via GUI
    Vector3 offset;
    Vector3 temp;
    void Start()
    {
        offset = transform.position - player.transform.position;
    }


    void FixedUpdate()
    {
        temp= player.transform.position + offset;
        if (temp.x > 9.66) //limita camera a direita
        {
            temp.x = 9.66f;
        }else if(temp.x < -9.66) //limita a camera a esquerda
        {
            temp.x = -9.66f;
        }
        if (temp.y < 0)//limita a camera abaixo
        {
            temp.y = 0f;
        }else if (temp.y > 5)
        {
            temp.y = 5f;
        }


        transform.position = temp;//travar a camera nas bordas
        
    }
}
