﻿using DG.Tweening;
using UnityEngine;

public class MiceController : MonoBehaviour {
    
    float movex;
    float movey;
    float nextplacex;
    float nextplacey;
    public GameObject flood;
    public Rigidbody2D rb;
    SpriteRenderer sr;
    private void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        flood = GameObject.Find("Flood");
        moving();
		
    }

    private void FixedUpdate()
    {
        if (transform.position.y > flood.gameObject.transform.position.y + 3.52f)
        {
            rb.gravityScale = 1f;
        }
        else if (transform.position.y >= flood.gameObject.transform.position.y + 3.5f)
        {
            rb.gravityScale = 0f;
            rb.velocity = new Vector2(rb.velocity.x, 0);
        }
        else
        {
            rb.gravityScale = -0.05f;
        }
    }


        
     


    void moving () {
        movex = Random.Range(-2, 3);
        if (movex < 0)
        {
            sr.flipX = false;
        }else if (movex > 0)
        {
            sr.flipX = true;
        }
        nextplacex = transform.position.x + movex;
        if (nextplacex <= -10.92f) {
            nextplacex = -10.92f;
        }
        if(nextplacex >= 10.92f)
        {
            nextplacex = 10.92f;
        }
        gameObject.transform.DOMoveX(nextplacex, 1f).SetEase(Ease.Linear).OnComplete(moving);
    }
}
