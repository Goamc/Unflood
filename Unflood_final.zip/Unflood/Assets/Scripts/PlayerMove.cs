﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerMove : MonoBehaviour
{
    public Rigidbody2D rb;
    
    public float xspd;
    public float yspd;
    
    public bool falling;
    public SpriteSwitcherPlayer sprite;
    private void Start()
    {
        sprite = GetComponent<SpriteSwitcherPlayer>();
        sprite.rightdir = true;
        sprite.state = 0;
        rb = GetComponent<Rigidbody2D>();
        
    }

    private void Awake()
    {
        
        falling = true;
    }

    private void FixedUpdate()
    {
        xspd = 0;
        yspd = 0;
       
            if (Input.GetKey(KeyCode.RightArrow) && Input.GetKey(KeyCode.UpArrow) && rb.velocity.y == 0)
            {
                xspd = 1;
                yspd = 3;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = true;
                sprite.state = 3;
            }
            else if (Input.GetKey(KeyCode.LeftArrow) && Input.GetKey(KeyCode.UpArrow) && rb.velocity.y == 0)
            {
                xspd = -1;
                yspd = 3;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = false;
                sprite.state = 3;
            }
            else if (Input.GetKey(KeyCode.UpArrow) && rb.velocity.y == 0)
            {
                yspd = 3;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.state = 3;
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                xspd = 1;
                rb.velocity = new Vector2(xspd, rb.velocity.y);
                sprite.rightdir = true;
                sprite.state = 1;
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                xspd = -1;
                rb.velocity = new Vector2(xspd, rb.velocity.y);
                sprite.rightdir = false;
                sprite.state = 1;
            }
            else if (rb.velocity.y == 0)
            {
                sprite.state = 0;
            }
        
        
    }

    
}