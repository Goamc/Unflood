﻿using UnityEngine;

public class WasteController : MonoBehaviour {
    public void OnMouseDown()
    {
        if (gameObject.tag == "WasteDestroy")
        {
            gameObject.SetActive(false);
        }
    }
}
