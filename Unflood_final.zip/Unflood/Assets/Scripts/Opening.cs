﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Opening : MonoBehaviour {
    string[] texto = new string[9];
    int cont;
    public GameObject player;//atribuido na cena
    public GameObject mouse;
    public GameObject medication;
    public GameObject waste;
    PlayerMove pc;
    bool talkable;
    void Start () {
        texto[0] = "Prefeito: Que bom que você veio! (clique no NPC)";
        texto[1] = "A nossa cidade está afundando na enchente...";
        texto[2] = "... precisamos que o lixo seja retirado de sobre os bueiros!";
        texto[3] = "Basta encostar no lixo e removê-lo (clicando com o mouse)!";
        texto[4] = "Apenas tome cuidado para não se afogar...";
        texto[5] = "... e cuidado com esses ratos, eles irão atacá-lo, estão por toda parte!";
        texto[6] = "Alguns medicamentos foram perdidos pela cidade por causa da enchente...";
        texto[7] = "...utilize-os caso necessário, não os desperdice!";
        texto[8] = "VÁ RÁPIDO!! NÃO TEMOS MAIS TEMPO! ->";
        cont = 0;
        talkable = true;
    }

    private void FixedUpdate()
    {
        if (player.transform.position.x>=-1f && talkable)
        {
            pc=player.GetComponent<PlayerMove>();
            pc.enabled = false;
            pc.sprite.state = 0;
            talking(0);
            talkable = false;
        }
        
        if (player.transform.position.x >= 1.6f)
        {
            SceneManager.LoadScene("scene1");
        }
    }
    public void talking(int idx)
    {
        Text talk = GameObject.Find("Text").GetComponent<Text>();
        talk.text = texto[idx];
        if (idx == 3)
        {
            waste.SetActive(true);
        }
        if (idx == 5)
        {
            mouse.SetActive(true);
        }
        if (idx == 6)
        {
            medication.SetActive(true);
        }

    }


    private void OnMouseDown()
    {
        if (cont < 9)
            {
                talking(cont);
                cont++;
        }
            else
            {
                mouse.SetActive(false);
                medication.SetActive(false);
                waste.SetActive(false);
                pc.enabled = true;
            }
    }

}
