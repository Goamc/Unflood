﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    public Rigidbody2D rb;
    public FloodController flood;
    public float xspd;
    public float yspd;
    public float health;
    public float breath;
    public int underwater;
    public bool falling;
    public SpriteSwitcherPlayer sprite;
    private void Start()
    {
        sprite = GetComponent<SpriteSwitcherPlayer>();
        sprite.rightdir = true;
        sprite.state = 0;
        rb = GetComponent<Rigidbody2D>();
        InvokeRepeating("breathing", 1f, 1f);
    }

    private void Awake()
    {
        health = 100;
        breath = 100;
        underwater = 0;
        falling = true;
    }

    private void FixedUpdate(){
        xspd = 0;
        yspd = 0;
       if (underwater==0) //fora da agua
        {
            if (Input.GetKey(KeyCode.RightArrow) && Input.GetKey(KeyCode.UpArrow) && rb.velocity.y == 0)
            {
                xspd = 1;
                yspd = 3;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = true;
                sprite.state = 3;
            }
            else if (Input.GetKey(KeyCode.LeftArrow) && Input.GetKey(KeyCode.UpArrow) && rb.velocity.y == 0)
            {
                xspd = -1;
                yspd = 3;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = false;
                sprite.state = 3;
            }
            else if (Input.GetKey(KeyCode.UpArrow) && rb.velocity.y == 0)
            {
                yspd = 3;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.state = 3;
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                xspd = 1;
                rb.velocity = new Vector2(xspd, rb.velocity.y);
                sprite.rightdir = true;
                sprite.state = 1;
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                xspd = -1;
                rb.velocity = new Vector2(xspd, rb.velocity.y);
                sprite.rightdir = false;
                sprite.state = 1;
            }
            else if (rb.velocity.y == 0)
            {
                sprite.state = 0;
            }
        }
        else if(underwater==2) //embaixo da agua
        {
            sprite.state = 2;
            if (Input.GetKey(KeyCode.RightArrow) && Input.GetKey(KeyCode.UpArrow))
            {
                xspd = 1;
                yspd = 1f;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = true;
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.LeftArrow) && Input.GetKey(KeyCode.UpArrow))
            {
                xspd = -1;
                yspd = 1f;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = false;
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.UpArrow))
            {
                yspd = 1f;
                rb.velocity = new Vector2(xspd, yspd);
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.DownArrow) && Input.GetKey(KeyCode.RightArrow))
            {
                yspd = -1f;
                xspd = 1;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = true;
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.DownArrow) && Input.GetKey(KeyCode.LeftArrow))
            {
                yspd = -1f;
                xspd = -1;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = false;
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            {
                yspd = -1f;
                rb.velocity = new Vector2(xspd, yspd);
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                xspd = 1;
                rb.velocity = new Vector2(xspd, rb.velocity.y);
                sprite.rightdir = true;
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                xspd = -1;
                rb.velocity = new Vector2(xspd, rb.velocity.y);
                sprite.rightdir = false;
                //sprite.state = 2;
            }
        }
        else //perto da superficie da agua
        {
            sprite.state = 2;
            if (Input.GetKey(KeyCode.RightArrow) && Input.GetKey(KeyCode.UpArrow))
            {
                xspd = 1;
                yspd = 3f;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = true;
                sprite.state = 3;
            }
            else if (Input.GetKey(KeyCode.LeftArrow) && Input.GetKey(KeyCode.UpArrow))
            {
                xspd = -1;
                yspd = 3f;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = false;
                sprite.state = 3;
            }
            else if (Input.GetKey(KeyCode.UpArrow))
            {
                yspd = 3f;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.state = 3;
            }
            else if (Input.GetKey(KeyCode.DownArrow) && Input.GetKey(KeyCode.RightArrow))
            {
                yspd = -1f;
                xspd = 1;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = true;
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.DownArrow) && Input.GetKey(KeyCode.LeftArrow))
            {
                yspd = -1f;
                xspd = -1;
                rb.velocity = new Vector2(xspd, yspd);
                sprite.rightdir = false;
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            {
                yspd = -1f;
                rb.velocity = new Vector2(xspd, yspd);
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                xspd = 1;
                rb.velocity = new Vector2(xspd, rb.velocity.y);
                sprite.rightdir = true;
                //sprite.state = 2;
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                xspd = -1;
                rb.velocity = new Vector2(xspd, rb.velocity.y);
                sprite.rightdir = false;
                //sprite.state = 2;
            }
        }
    }

    private void breathing()
    {
        if (transform.position.y >= flood.transform.position.y + 3.455f)
        {
            if (breath != 100) {
                gainBreath(5f);
            }
        }
        else
        {
            loseBreath(4f);
        }
        UpdateScoreUI();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Waste")
        {
            collision.gameObject.tag = "WasteDestroy";
        }else if (collision.gameObject.tag == "Respawn")
        {
            loseHealth(10f);
        }else if (collision.gameObject.tag == "Medication")
        {
            gainHealth(10f);
            collision.gameObject.SetActive(false);
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Respawn")
        {
            UpdateScoreUI();
            loseHealth(0.01f);
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "WasteDestroy")
        {
            collision.gameObject.tag = "Waste";
        }
    }

    

    public void loseHealth(float qtd)
    {
        health = health - qtd;
        if (health <= 0)
        {
            GameController.updateGame(false);
            return;
        }
    }
    public void gainHealth(float qtd)
    {
        health = health + qtd;
    }
    public void loseBreath(float qtd)
    {
        breath = breath - qtd;
        if (breath <= 0)
        {
            GameController.updateGame(false);
            return;
        }
    }
    public void gainBreath(float qtd)
    {
        if (breath + qtd <= 100)
        {
            breath = breath + qtd;
        }
        else
        {
            breath = 100;
        }
    }

    public void UpdateScoreUI()
    {
        Text folego = GameObject.Find("Text").GetComponent<Text>();
        

        folego.text = "Fôlego: "+breath.ToString()+"/100 Saúde: "+health.ToString()+"/100";
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (transform.position.y>=collision.gameObject.transform.position.y+0.190f)
        {
            collision.gameObject.SetActive(false);
        }
    }
}