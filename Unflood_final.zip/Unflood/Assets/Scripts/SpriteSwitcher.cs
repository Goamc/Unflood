﻿using UnityEngine;

public class SpriteSwitcher : MonoBehaviour
{
    public Sprite[] sprites; //definido na GUI
    public float interval;

    SpriteRenderer sr;
    float curTime;
    int spriteIdx;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        curTime += Time.deltaTime;
        if (curTime >= interval)
        {
            curTime -= interval;
            spriteIdx = (spriteIdx + 1) % sprites.Length; 
            sr.sprite = sprites[spriteIdx];
        }
    }
}
