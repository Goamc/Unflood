﻿using UnityEngine;
using DG.Tweening;
using UnityEngine.SceneManagement;
public class FloodController : MonoBehaviour
{
    public PlayerController player; //instanciado na GUI
    public float ini = -4.5f;//posicao inicio, definido por GUI (varia com o mapa)
    public float limit; //posicao onde a fase ira parar, definido na cena, definido por GUI (varia com o mapa)
    public float ground; //posicao onde a agua atinge o nivel do solo mais baixo, definido por GUI (varia com o mapa)
    public float vel_pps; //velocidade em pixels por segundo, definido por GUI (varia com o mapa)
    float speed;
    float spread_effect;
    float contSewer;
    float totalSewer;
    public GameObject mouse;
    public float respawn;


    private void Awake()
    {
        DOTween.Init();
    }
    private void Start()
    {
        totalSewer = GameObject.FindGameObjectsWithTag("Sewer").Length+ GameObject.FindGameObjectsWithTag("FreeSewer").Length;
        contSewer = totalSewer;
        spread_effect = 2;
        speed = vel_pps;
        moveWater();
        for (int i = 0; i < 5; i++)
        {
            GameObject inst = Instantiate<GameObject>(mouse);
            inst.transform.position = new Vector2(-5, respawn);
        }
        for (int i = 0; i < 5; i++)
        {
            GameObject inst = Instantiate<GameObject>(mouse);
            inst.transform.position = new Vector2(5, respawn);
        }
    }
    
    private void FixedUpdate()
    {
        if (player.transform.position.y >=transform.position.y+3.5f)
        {
            player.falling = true;
            player.underwater = 0;
            player.rb.gravityScale = 1;
        }
        else if (player.transform.position.y >= transform.position.y + 3.355f)
        {
            player.underwater = 1;
            player.rb.gravityScale = -0.05f;
            if (player.falling)
            {
                if (player.rb.velocity.y < -1f)
                {
                    player.rb.velocity = new Vector2(player.xspd, -0.5f); //atenua pousos na agua
                }else if (player.rb.velocity.y < 0)
                {
                    player.rb.velocity = new Vector2(player.xspd, 0);
                }
            }
            player.falling = false;
        }
        else
        {
            player.underwater = 2;
            player.rb.gravityScale = -0.05f;
            player.falling = false;
        }
        /*a agua sobe mais rapido quando nao esta espalhada pela superficie
          ao passar o nivel do solo começa a se espalhar, entao a velocidade diminui
        */
        if (gameObject.transform.position.y >= ground)
        {
            spread_effect=1;
        }
        else
        {
            spread_effect = 2;
        }

        
        contSewer = GameObject.FindGameObjectsWithTag("Sewer").Length;
        if (gameObject.transform.position.y < ini)
        {
            GameController.health = player.health;
            GameController.updateGame(true);
        }
        else if (gameObject.transform.position.y >= limit)
        {
            GameController.updateGame(false);
        }
    }

    private void moveWater() 
    {
        speed = (spread_effect* vel_pps * (contSewer / totalSewer)) -12;
        float pixels = gameObject.transform.position.y+((speed/100));
        gameObject.transform.DOMoveY(pixels, 1).SetEase(Ease.Linear).OnComplete(() => moveWater());
    }
}
