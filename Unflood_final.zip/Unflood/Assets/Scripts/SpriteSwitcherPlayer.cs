﻿using UnityEngine;

public class SpriteSwitcherPlayer : MonoBehaviour
{
    public Sprite[] sprites; //definido na GUI
    public float interval;
    SpriteRenderer sr;
    float curTime;
    int spriteIdx;
    public bool rightdir;
    public int state; //0=stop,1=walking,2=swimming,3=jumping
    void Start()
    {
        rightdir = true;
        state = 0;
        sr = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        sr.flipX = rightdir;
        curTime += Time.deltaTime;
        if (state == 0)
        {
            sr.sprite = sprites[0];
        } else if (state==3) {
            sr.sprite = sprites[4];
        } else if (curTime >= interval)
        {
            if (state == 1)
            {
                curTime -= interval;
                spriteIdx = (spriteIdx + 1) % 4;
                sr.sprite = sprites[spriteIdx];
            }
            else if (state == 2)
            {
                curTime -= interval;
                spriteIdx = (spriteIdx + 1) % 3;
                sr.sprite = sprites[spriteIdx+5];
            }
        }
    }
}
