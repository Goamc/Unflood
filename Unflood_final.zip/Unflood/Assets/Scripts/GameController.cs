﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class GameController : MonoBehaviour
{
    
    public static float health;
    public static float breath;
    
    public static PlayerController player;
    

    private void Awake()
    {
        DontDestroyOnLoad(this);        
    }

    private void Update()
    {
        if(SceneManager.GetActiveScene().buildIndex==0 && Input.GetKey(KeyCode.Space))
        {
            updateGame(true);
        }
    }
    public static void updateGame(bool win)
    {
        if (win)
        {
            int idx = SceneManager.GetActiveScene().buildIndex;
            SceneManager.LoadScene(idx + 1);
        }
        else
        {
            SceneManager.LoadScene("GameOver");
        }
    }

   
}
